﻿using ProvaIdealSoft.Domain.Core.Interfaces.Repositories;
using ProvaIdealSoft.Domain.Core.Interfaces.Services;
using ProvaIdealSoft.Domain.Entities;

namespace ProvaIdealSoft.Domain.Services
{
    public class ServicePessoa : ServiceBase<Pessoa>, IServicePessoa
    {
        private readonly IPessoaRepository _repositoryPessoa;

        public ServicePessoa(IPessoaRepository RepositoryPessoa)
            : base(RepositoryPessoa)
        {
            _repositoryPessoa = RepositoryPessoa;
        }       
    }
}
