CREATE TABLE [dbo].[Pessoa]
(
	[PessoaId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Nome] VARCHAR(100) NOT NULL,
	[Sobrenome] VARCHAR(100) NOT NULL,
	[Telefone] VARCHAR(24) NOT NULL,
	[DataCadastro] DATETIME 
);