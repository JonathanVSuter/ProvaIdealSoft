﻿using ProvaIdealSoft.Models;

namespace ProvaIdealSoft.Repositories.Interfaces
{
    public interface IRepositoryPessoa : IBaseRepository<Pessoa>
    {
    }
}
