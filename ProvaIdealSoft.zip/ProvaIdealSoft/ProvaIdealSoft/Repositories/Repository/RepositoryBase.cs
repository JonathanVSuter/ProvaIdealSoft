﻿using Newtonsoft.Json;
using ProvaIdealSoft.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ProvaIdealSoft.Repositories.Repository
{
    public class RepositoryBase<T> : IBaseRepository<T> where T : class
    {
        private readonly string BaseUrl;
        private readonly string Entity;
        private HttpClient httpClient { get; set; }

        public RepositoryBase()
        {           
            if(BaseUrl == null)
            {                
                BaseUrl = $"https://localhost:44397";
            }
            if(Entity == null)
            {
                Entity = typeof(T).Name.ToLower();
            }
            if(httpClient== null)
            {
                httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(BaseUrl);
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            }
        }
        public async Task<bool> Add(T obj)
        {
            try
            {
                HttpResponseMessage response = await httpClient.PostAsJsonAsync<T>($"/{Entity}", obj);
                response.EnsureSuccessStatusCode();
                return response.StatusCode == System.Net.HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void Dispose()
        {
            this.httpClient.Dispose();
        }
        public async Task<IEnumerable<T>> GetAll()
        {
            try 
            {
                HttpResponseMessage responseMessage = await httpClient.GetAsync($"/{Entity}").ConfigureAwait(true);
                responseMessage.EnsureSuccessStatusCode();
                return  await responseMessage.Content.ReadAsAsync<IEnumerable<T>>().ConfigureAwait(true);               
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        public async Task<T> GetById(int id)
        {
            HttpResponseMessage responseMessage = await httpClient.GetAsync($"/{Entity}/{id}").ConfigureAwait(true);
            responseMessage.EnsureSuccessStatusCode();
            return await responseMessage.Content.ReadAsAsync<T>().ConfigureAwait(true);              
        }
        public async Task<bool> Remove(T obj)
        {
            try
            {
                HttpResponseMessage response = await httpClient.PostAsJsonAsync<T>($"/{Entity}/delete",obj);
                response.EnsureSuccessStatusCode();
                return response.StatusCode == System.Net.HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<bool> Update(T obj)
        {
            try
            {                
                HttpResponseMessage response = await httpClient.PutAsJsonAsync<T>($"/{Entity}",obj);
                response.EnsureSuccessStatusCode();
                return response.StatusCode == System.Net.HttpStatusCode.OK; 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
