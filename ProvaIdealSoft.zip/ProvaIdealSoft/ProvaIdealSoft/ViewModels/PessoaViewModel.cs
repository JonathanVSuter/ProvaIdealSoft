﻿using ProvaIdealSoft.Base;
using ProvaIdealSoft.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;

namespace ProvaIdealSoft.ViewModels
{
    public class PessoaViewModel : BaseViewModel<Pessoa>
    {
        public string Titulo { get; set; }
        public bool BtnRemoverVisivel 
        {
            get 
            {
                return (Item!=null) && (Item.id != 0);
            }
            private set { }
        }
        public PessoaViewModel() 
        {
           Titulo = "Listagem de Pessoas";            
        }        
    }
}
