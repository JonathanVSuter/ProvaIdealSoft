﻿using ProvaIdealSoft.Commands;
using ProvaIdealSoft.Repositories.Repository;
using ProvaIdealSoft.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace ProvaIdealSoft.Base
{
    public class BaseViewModel<T>: BaseModel  where T : class 
    {

        #region Fields
        private readonly RepositoryBase<T> RepositoryBase;
        private Queue<T> ItensQueue { get; set; }
        private T _Item;
        public T Item 
        {
            get 
            {
                return _Item;
            }
            set 
            {
                Set(ref _Item, value);
            }
        }
        public ObservableCollection<T> Items { get;private set; }
        #endregion
        #region Constructors
        public BaseViewModel() 
        {
            Items = new ObservableCollection<T>();
            Item = (T)Activator.CreateInstance(typeof(T), Array.Empty<object>());
            RepositoryBase = (RepositoryBase<T>)Activator.CreateInstance(typeof(RepositoryBase<T>), Array.Empty<object>());
            ItensQueue = (Queue<T>)Activator.CreateInstance(typeof(Queue<T>), Array.Empty<object>());            
        }
        #endregion
        #region Crud Operations
        public async Task<bool> Adicionar(T value) 
        {
            bool retorno = await RepositoryBase.Add(value).ConfigureAwait(true);
            if(retorno)
            {
                //Items.Add(value);
                Items.Clear();
            }
            InserirItensFila();
            return retorno;
        }
        public async Task<bool> Atualizar(T value)
        {
            if (value != null)
            {
                T item;
                item = Items.Where(x=>((IBaseModel)x).ToString() == ((IBaseModel)value).ToString()).FirstOrDefault();
                
                if (item != null)
                {
                    int posicao;
                    posicao = Items.IndexOf(item);
                    foreach (PropertyInfo property in typeof(T).GetProperties())
                    {
                        //não é a melhor forma de excluir o Id da alteração:
                        if(!property.Name.Equals("id", StringComparison.CurrentCultureIgnoreCase))
                        {
                            if (property.GetValue(value, null) != property.GetValue(Items[posicao], null))
                            {
                                property.SetValue(Items[posicao], property.GetValue(value, null));
                                Changed<T>(property.Name); // atualizar somente uma propriedade
                            }
                        }                        
                    }
                    return await RepositoryBase.Update(value).ConfigureAwait(true);
                }
                return false;
            }
            else
            {
                return false;
            }

        }
        public async Task<bool> Remover(T value)
        {
            bool retorno=false;
            if (value != null)
            {
                T item;
                item = Items.Where(x => ((IBaseModel)x).Id() == ((IBaseModel)value).Id()).FirstOrDefault();
                retorno = await RepositoryBase.Remove(item).ConfigureAwait(true);
                Items.Remove(item);
            }
            return retorno;
        }
        public async Task<IEnumerable<T>> Obter(Func<T, bool> func)
        {
            //não é a forma mais correta, o correto seria implementar um método na controller que se adequa-se para diminuir o I/O
            return ((await RepositoryBase.GetAll().ConfigureAwait(true)).Where(func)).ToList();
        }
        public Task<IEnumerable<T>> Listar()
        {
            return RepositoryBase.GetAll();
        }        
        #endregion
        #region Commands
        public DeletePessoaCommand Delete { get; private set; } = new DeletePessoaCommand();
        public CreatePessoaCommand Create { get; private set; } = new CreatePessoaCommand();
        public AtualizarPessoaCommand Update { get; private set; } = new AtualizarPessoaCommand();
        #endregion
        #region Ações Diversas
        public async void InserirItensFila() 
        {
            foreach(T item in (await Listar().ConfigureAwait(true)))
            {
                ItensQueue.Enqueue(item);
            }
            EsvaziarFila();
        }
        private void EsvaziarFila() 
        {
            while (ItensQueue.Count>0) 
            {
                Items.Add(ItensQueue.Dequeue());
            }
        }
        #endregion
    }
}
