﻿using ProvaIdealSoft.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProvaIdealSoft.Models
{
    public class Pessoa : BaseModel, IBaseModel
    {

        public int Id()
        {
            return id;
        }
        private int _id;
        public int id 
        {
            get 
            {
                return _id;
            }
            set 
            {
                Set(ref _id, value);
                Changed(() => id);
            }
        }
        private string _Nome;
        public string Nome 
        {
            get 
            {
                return _Nome;
            }
            set 
            {
                Set(ref _Nome, value);
                Changed(() => Nome);
            } 
        }
        private string _Sobrenome;
        public string Sobrenome 
        {
            get 
            {
                return _Sobrenome;
            }
            set 
            {
                Set(ref _Sobrenome, value);
                Changed(() => Sobrenome);
            } 
        }
        private string _Telefone;
        public string Telefone 
        {
            get 
            {
                return _Telefone;
            }
            set 
            {
                Set(ref _Telefone, value);
                Changed(() => Telefone);
            } 
        }
        public override string ToString()
        {
            return Id().ToString();
        }
    }
}
