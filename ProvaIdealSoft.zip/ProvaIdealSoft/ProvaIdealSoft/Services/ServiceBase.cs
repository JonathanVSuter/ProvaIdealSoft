﻿using ProvaIdealSoft.Interfaces;
using ProvaIdealSoft.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ProvaIdealSoft.Services
{
    public abstract class ServiceBase<T> : IServiceBase<T> where T : class
    {

        private readonly IBaseRepository<T> _repository;
        
        public ServiceBase(IBaseRepository<T> Repository)
        {
            _repository = Repository;
        }
        public virtual Task<bool> Add(T obj)
        {
            return _repository.Add(obj);
        }
        public virtual Task<T> GetById(int id)
        {
            return _repository.GetById(id);
        }
        public virtual Task<IEnumerable<T>> GetAll()
        {
            return _repository.GetAll();
        }
        public virtual Task<bool> Update(T obj)
        {
            return _repository.Update(obj);
        }
        public virtual Task<bool> Remove(T obj)
        {
            return _repository.Remove(obj);
        }
    }
}
