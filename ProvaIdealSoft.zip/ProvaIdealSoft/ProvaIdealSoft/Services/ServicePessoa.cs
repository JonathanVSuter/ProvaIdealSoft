﻿using ProvaIdealSoft.Interfaces;
using ProvaIdealSoft.Models;
using ProvaIdealSoft.Repositories.Interfaces;


namespace ProvaIdealSoft.Services
{
    public class ServicePessoa : ServiceBase<Pessoa>, IServicePessoa
    {
        private readonly IRepositoryPessoa _repositoryPessoa;

        public ServicePessoa(IRepositoryPessoa RepositoryPessoa)
            : base(RepositoryPessoa)
        {
            _repositoryPessoa = RepositoryPessoa;
        }
    }
}
