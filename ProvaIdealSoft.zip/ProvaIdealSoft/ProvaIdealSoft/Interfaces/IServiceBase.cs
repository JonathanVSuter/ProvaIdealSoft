﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProvaIdealSoft.Interfaces
{
    public interface IServiceBase<T> where T: class
    {
        Task<bool> Add(T obj);

        Task<T> GetById(int id);

        Task<IEnumerable<T>> GetAll();

        Task<bool> Update(T obj);

        Task<bool> Remove(T obj);
    }
}
