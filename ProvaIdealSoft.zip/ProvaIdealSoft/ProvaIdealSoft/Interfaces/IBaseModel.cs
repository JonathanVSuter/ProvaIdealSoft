﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProvaIdealSoft
{
    public interface IBaseModel
    {
        public int Id ();
    }
}
