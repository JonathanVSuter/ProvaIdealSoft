﻿using ProvaIdealSoft.Interfaces;
using ProvaIdealSoft.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProvaIdealSoft.Interfaces
{
    public interface IServicePessoa : IServiceBase<Pessoa> 
    {
    }
}
