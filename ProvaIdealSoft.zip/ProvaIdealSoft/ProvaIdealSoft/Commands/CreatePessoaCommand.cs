﻿using ProvaIdealSoft.Base;
using ProvaIdealSoft.Models;
using ProvaIdealSoft.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProvaIdealSoft.Commands
{    
    public class CreatePessoaCommand : BaseCommand<Pessoa>
    {
        public override bool CanExecute(object parameter)
        {
            return parameter != null;
        }
        public async override void Execute(object parameter)
        {
            _BaseViewModel = (PessoaViewModel)parameter;
            if (_BaseViewModel.Item.id == 0)
            {
                await _BaseViewModel.Adicionar(_BaseViewModel.Item).ConfigureAwait(true);
            }
            else 
            {
                await _BaseViewModel.Atualizar(_BaseViewModel.Item).ConfigureAwait(true);
            }            
        }
    }
}
