﻿using ProvaIdealSoft.Models;
using ProvaIdealSoft.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProvaIdealSoft.Views
{
    /// <summary>
    /// Interaction logic for PessoaListPage.xaml
    /// </summary>
    public partial class PessoaListPage : Window
    {
        private readonly PessoaViewModel Contexto;
        public PessoaListPage()
        {
            InitializeComponent();
            DataContext = Contexto = new PessoaViewModel();
            Contexto.InserirItensFila();
        }        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Contexto.Item = new Pessoa();
            PessoaDetailPage pessoaDetailPage = new PessoaDetailPage(Contexto);            
            pessoaDetailPage.ShowDialog();
        }

        private void ListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (Contexto != null)
            {
                Contexto.Item = (Pessoa)Contexto.Item.Clone();
                PessoaDetailPage pessoaDetailPage = new PessoaDetailPage(Contexto);
                pessoaDetailPage.ShowDialog();
            }
        }
    }
}
