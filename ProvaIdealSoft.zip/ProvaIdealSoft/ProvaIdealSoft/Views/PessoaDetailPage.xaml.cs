﻿using ProvaIdealSoft.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ProvaIdealSoft.Views
{
    /// <summary>
    /// Interaction logic for PessoaDetailPage.xaml
    /// </summary>
    public partial class PessoaDetailPage : Window
    {
        private readonly PessoaViewModel Contexto;
        public PessoaDetailPage()
        {
            InitializeComponent();
        }
        public PessoaDetailPage(PessoaViewModel viewModel)
        {
            InitializeComponent();
            if (viewModel != null)
            {
                DataContext = Contexto =  viewModel;
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {/*
            if((Contexto.Item!=null) && (Contexto.Item.PessoaId==0))
            {
                Contexto.Adicionar(Contexto.Item);
            }
            else 
            {
                Contexto.Atualizar(Contexto.Item);                
            }   */         
            Close();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {            
            Close();
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
