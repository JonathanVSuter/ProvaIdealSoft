﻿using System;

namespace ProvaIdealSoft.Domain.Entities
{
    public class Pessoa: IBaseModel
    {   
        public int PessoaId { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public string Telefone { get; set; }
        public DateTime DataCadastro { get; set; }
        public int Id()
        {
            return PessoaId;
        }
    }
}
