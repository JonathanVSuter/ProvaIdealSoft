﻿namespace ProvaIdealSoft.Domain.Entities
{
    public interface IBaseModel
    {        
        public int Id();
    }
}
