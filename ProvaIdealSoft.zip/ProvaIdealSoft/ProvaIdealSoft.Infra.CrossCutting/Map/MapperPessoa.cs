﻿using ProvaIdealSoft.Application.DTO.DTO;
using ProvaIdealSoft.Domain.Entities;
using ProvaIdealSoft.Infra.CrossCutting.Adapter.Interfaces;

using System.Collections.Generic;


namespace ProvaIdealSoft.Infra.CrossCutting.Adapter.Map
{
    public class MapperPessoa : IMapperPessoa
    {
        List<PessoaDTO> PessoaDTOs = new List<PessoaDTO>();
        public IEnumerable<PessoaDTO> MapperListPessoas(IEnumerable<Pessoa> pessoas)
        {
            foreach (Pessoa item in pessoas)
            {

                PessoaDTO pessoaDTO = new PessoaDTO
                {
                    Id = item.PessoaId
                   ,
                    Nome = item.Nome
                   ,
                    Sobrenome = item.Sobrenome
                   ,
                    Telefone = item.Telefone
                };
                PessoaDTOs.Add(pessoaDTO);
            }
            return PessoaDTOs;
        }

        public PessoaDTO MapperToDTO(Pessoa pessoa)
        {
            PessoaDTO pessoaDTO = new PessoaDTO
            {
                Id = pessoa.PessoaId
                ,
                Nome = pessoa.Nome
                ,
                Sobrenome = pessoa.Sobrenome
                ,
                Telefone = pessoa.Telefone
            };
            return pessoaDTO;
        }
        public Pessoa MapperToEntity(PessoaDTO pessoaDTO)
        {
            Pessoa pessoa = new Pessoa
            {
                PessoaId = pessoaDTO.Id
                ,
                Nome = pessoaDTO.Nome
                ,
                Sobrenome = pessoaDTO.Sobrenome
                ,
                Telefone = pessoaDTO.Telefone
            };
            return pessoa;
        }
    }
}
