﻿using ProvaIdealSoft.Application.DTO.DTO;
using ProvaIdealSoft.Domain.Entities;

using System.Collections.Generic;


namespace ProvaIdealSoft.Infra.CrossCutting.Adapter.Interfaces
{
    public interface IMapperPessoa
    {
        Pessoa MapperToEntity(PessoaDTO pessoaDTO);

        IEnumerable<PessoaDTO> MapperListPessoas(IEnumerable<Pessoa> pessoas);

        PessoaDTO MapperToDTO(Pessoa pessoa);
    }
}
