﻿using ProvaIdealSoft.Domain.Entities;

namespace ProvaIdealSoft.Domain.Core.Interfaces.Services
{
    public interface IServicePessoa:IServiceBase<Pessoa>
    {
    }
}
