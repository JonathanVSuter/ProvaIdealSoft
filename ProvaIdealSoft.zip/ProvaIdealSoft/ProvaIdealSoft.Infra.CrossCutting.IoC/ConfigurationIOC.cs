﻿using Autofac;
using ProvaIdealSoft.Application.Interfaces;
using ProvaIdealSoft.Application.Services;
using ProvaIdealSoft.Domain.Core.Interfaces.Repositories;
using ProvaIdealSoft.Domain.Core.Interfaces.Services;
using ProvaIdealSoft.Domain.Services;
using ProvaIdealSoft.Infra.CrossCutting.Adapter.Interfaces;
using ProvaIdealSoft.Infra.CrossCutting.Adapter.Map;
using ProvaIdealSoft.Infra.Data.Repository;

namespace ProvaIdealSoft.Infra.CrossCutting.IoC
{
    public class ConfigurationIOC
    {
        public static void Load(ContainerBuilder builder)
        {
            #region Registra IOC

            #region IOC Application
            builder.RegisterType<ApplicationServicePessoa>().As<IApplicationServicePessoa>();
           
            #endregion

            #region IOC Services
            builder.RegisterType<ServicePessoa>().As<IServicePessoa>();
            #endregion

            #region IOC Repositorys SQL
            builder.RegisterType<RepositoryPessoa>().As<IPessoaRepository>();
            #endregion

            #region IOC Mapper
            builder.RegisterType<MapperPessoa>().As<IMapperPessoa>();
            #endregion

            #endregion

        }
    }
}
