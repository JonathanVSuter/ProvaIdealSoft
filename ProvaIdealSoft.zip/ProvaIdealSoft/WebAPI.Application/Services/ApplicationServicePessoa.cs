﻿using ProvaIdealSoft.Application.DTO.DTO;
using ProvaIdealSoft.Application.Interfaces;
using ProvaIdealSoft.Domain.Core.Interfaces.Services;
using ProvaIdealSoft.Infra.CrossCutting.Adapter.Interfaces;
using System.Collections.Generic;

namespace ProvaIdealSoft.Application.Services
{
    public class ApplicationServicePessoa : IApplicationServicePessoa
    {
        private readonly IServicePessoa _servicePessoa;
        private readonly IMapperPessoa _mapperPessoa;

        public ApplicationServicePessoa(IServicePessoa ServicePessoa, IMapperPessoa MapperPessoa)
        {
            _servicePessoa = ServicePessoa;
            _mapperPessoa = MapperPessoa;
        }
        public void Add(PessoaDTO obj)
        {
            var objPessoa = _mapperPessoa.MapperToEntity(obj);
            _servicePessoa.Add(objPessoa);
        }
        public void Dispose()
        {
            _servicePessoa.Dispose();
        }
        public IEnumerable<PessoaDTO> GetAll()
        {
            var objPessoa = _servicePessoa.GetAll();
            return _mapperPessoa.MapperListPessoas(objPessoa);
        }
        public PessoaDTO GetById(int id)
        {
            var objPessoa = _servicePessoa.GetById(id);
            return _mapperPessoa.MapperToDTO(objPessoa);
        }
        public void Remove(PessoaDTO obj)
        {
            var objPessoa = _mapperPessoa.MapperToEntity(obj);
            _servicePessoa.Remove(objPessoa);
        }
        public void Update(PessoaDTO obj)
        {
            var objPessoa = _mapperPessoa.MapperToEntity(obj);
            _servicePessoa.Update(objPessoa);
        }
    }
}
