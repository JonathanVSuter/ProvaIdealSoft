﻿using ProvaIdealSoft.Application.DTO.DTO;
using System.Collections.Generic;


namespace ProvaIdealSoft.Application.Interfaces
{    
    public interface IApplicationServicePessoa
    {
        void Add(PessoaDTO obj);

        PessoaDTO GetById(int id);

        IEnumerable<PessoaDTO> GetAll();

        void Update(PessoaDTO obj);

        void Remove(PessoaDTO obj);

        void Dispose();
    }
}
