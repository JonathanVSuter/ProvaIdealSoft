﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ProvaIdealSoft.Application.DTO.DTO;
using ProvaIdealSoft.Application.Interfaces;

namespace ProvaIdealSoft.Presentation.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PessoaController : Controller
    {
        private readonly IApplicationServicePessoa _applicationServicePessoa;
        public PessoaController(IApplicationServicePessoa ApplicationServicePessoa)
        {
            _applicationServicePessoa = ApplicationServicePessoa;
        }
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {            
            return Ok(_applicationServicePessoa.GetAll());
        }
        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return Ok(_applicationServicePessoa.GetById(id));
        }
        // POST api/values
        [HttpPost]
        public ActionResult Post([FromBody] PessoaDTO pessoaDTO)
        {
            try
            {
                if (pessoaDTO == null)
                    return NotFound();

                _applicationServicePessoa.Add(pessoaDTO);
                return Ok("Pessoa criada com sucesso!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // PUT api/values/5
        [HttpPut]
        public ActionResult Put([FromBody] PessoaDTO pessoaDTO)
        {
            try
            {
                if (pessoaDTO == null)
                    return NotFound();

                _applicationServicePessoa.Update(pessoaDTO);
                return Ok("Pessoa Atualizada com sucesso!");
            }
            catch (Exception)
            {

                throw;
            }
        }
        // DELETE api/values/{}
        [HttpPost]
        [Route("/pessoa/delete")]
        public ActionResult DeleteObject([FromBody] PessoaDTO pessoaDTO)
        {
            try
            {
                if (pessoaDTO == null)
                    return NotFound();

                _applicationServicePessoa.Remove(pessoaDTO);
                return Ok("Pessoa removida com sucesso!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpDelete()]
        public ActionResult Delete([FromBody] PessoaDTO pessoaDTO)
        {
            try
            {
                if (pessoaDTO == null)
                    return NotFound();

                _applicationServicePessoa.Remove(pessoaDTO);
                return Ok("Pessoa removida com sucesso!");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
