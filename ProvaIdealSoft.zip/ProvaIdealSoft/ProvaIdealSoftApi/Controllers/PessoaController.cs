﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ProvaIdealSoft.Domain.Entities;

namespace ProvaIdealSoftApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PessoaController : Controller
    {        
        [HttpGet]
        public IEnumerable<Pessoa> GetPessoas() 
        {
            return new List<Pessoa> 
            {
                new Pessoa()
                {
                    PessoaId = 1,
                    Nome = "Jão",
                    Sobrenome = "Jão",
                    Telefone = "47 99999-9999"
                },
                new Pessoa()
                {
                    PessoaId = 2,
                    Nome = "Jão",
                    Sobrenome = "Jão",
                    Telefone = "47 99999-9999"
                },
                new Pessoa()
                {
                    PessoaId = 3,
                    Nome = "Jão",
                    Sobrenome = "Jão",
                    Telefone = "47 99999-9999"
                },
                new Pessoa()
                {
                    PessoaId = 4,
                    Nome = "Jão",
                    Sobrenome = "Jão",
                    Telefone = "47 99999-9999"
                },
                new Pessoa()
                {
                    PessoaId = 5,
                    Nome = "Jão",
                    Sobrenome = "Jão",
                    Telefone = "47 99999-9999"
                }
            };
        }        
        public IActionResult Index()
        {
            return View();
        }
    }
}
