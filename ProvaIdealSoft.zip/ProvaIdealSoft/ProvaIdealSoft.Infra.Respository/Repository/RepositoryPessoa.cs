﻿using ProvaIdealSoft.Domain.Core.Interfaces.Repositories;
using ProvaIdealSoft.Domain.Entities;

namespace ProvaIdealSoft.Infra.Data.Repository
{
    public class RepositoryPessoa : RepositoryBase<Pessoa>, IPessoaRepository
    {
        private readonly SqlContext _context;
        public RepositoryPessoa(SqlContext Context)
            : base(Context)
        {
            _context = Context;
        }
    }
}
